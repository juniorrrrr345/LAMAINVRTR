// Export de la fonction connectToDatabase depuis mongodb-runtime
export { connectToDatabase } from './mongodb-runtime';